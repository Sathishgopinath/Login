<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>View Resume</title>

	<link rel="stylesheet" href="resumes.css">
<style>

.fcontainer {
  width: 100%;
  /*height: 100%;*/
  /* min-height: 15vh; */
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  padding: 15px;
  top: 15%;
  position: relative;
  z-index: 0;
  
}

.form_head {
  width: 1200px;
  min-height: 1200px;
  background-color: white;
  border-radius: 10px;
  overflow: hidden;
  position: relative;
  box-shadow: -10px 10px 100px 20px black;
  box-shadow: inset;
}

.form_title {
  width: 100%;
  height: 23%;
  position: relative;
  z-index: 0;
  font-size: 20px;
  display: flex;
  flex-direction: row;
  align-items: center;
  background-color: teal;
  /*padding: 64px 15px 64px 15px;*/
}

.form_containers {
  width: 100%;
  height: 100%;
  font-size: 13px;
  /* border: 5px solid blue; */
  display: flex;
  flex-direction: row;
  /*align-items: right;*/
  

}
.form_containers h2{
	font-size: 25px;
	font-weight: bold;
	padding-top: 25px;
}

.left{
	width: 26%;
	height: 100%;
	/* border: 5px solid red; */
	padding: 35px 15px;
	/*display: inline-block;*/
}
.right{
	width: 70%;
	height: 100%;
	padding: 25px 20px;
}
.em_detail{
	border-left: 5px solid black;
	padding-left: 28px;
}
.name_cont{
	width: 70%;
	height: 53%;
	color: white;
	/*border: 5px solid red;*/
	text-align: right;
	padding: 10px 20px;
}
.form_image{
	/*border: 2px solid green;*/
	width: 20%;
	height: 100%;
	padding: 13px;
	text-align: right;
	z-index: 0;
}

.con_info{
	overflow-wrap: auto;
	padding: 0 30px;
	line-height: 5vh;
	font-size: 19px;
	font-weight: bold;
	position: relative;
	padding-bottom: 10px;
	/* border-bottom: 5px solid black; */
}
h1{
	font-size: 23px;
}
table,th, td {
	
	font-size: 25px;
	border: 2px solid black;
	padding: 10px 70px;
	border-collapse: collapse;
}

footer{
  
  color: white;
  background:teal;
  width:100%;
  height:20%;
  z-index:1;
  text-align:center;
  padding: 10px;
  margin-top: 25px;
  border-radius: 30px;
}

</style>

</head>
<body>

<?php
		session_start();
		if (!isset($_SESSION['email'])){
			header("location:index.php?sass=''");
			
			if (!isset($_SESSION['name'])){
			header("location:resumes.php?sass=''");
	}
		}	
?>

<script>
	if ( window.history.replaceState ) {
	  window.history.replaceState( null, null, window.location.href );
	}
</script>

<div class="container">
    <nav class="navbar">
    <div>
		<img src="rlogo1crop.png" width="60px" height="60px" style="filter: drop-shadow(0 0 0.75rem white);">
	</div>
    
      <ul class="nav-links">
        <div class="menu">
          <li><a href="#">Home</a></li>
          <li><a href="#" id = "rescls" onclick="openNav()">Resume</a></li>
          <li><a href="#" id = "accls" onclick="openNav2()">Account Details </a></li>
          <li><a href="#">About</a></li>

            <li><a href="logout.php">Logout?</a></li>
      
        </div>
      </ul>
    </nav>

	<div class="container-page">
		
		<div id="mySidenav" class="sidenav">
			<a href="#" class="closebtn" onclick="closeNav()">&times;</a>
			<a href="resumes.php">Create Resume</a>
			<a href="#">View Resume</a>
			<a href="#" disabled >Edit Resume</a>

		</div>

		<div id="mySidenav2" class="sidenav">
			<a href="#" class="closebtn" onclick="closeNav2()">&times;</a>
			<a href="#" disabled>Account Details</a>
			<a href="change_pass.php">Change Password</a>
			<a href="#" disabled>Delete Account</a>

		</div>

	</div>

	</div>

  <h2 class = "uname" >
    <?php  
        // $string = $_SESSION['lemail'];
        // $newString = substr($string, 0, strpos($string, "@"));
        // echo "Welcome ".strtoupper($newString);
    ?>
  </h2>
		
	<div class="container-page">
	
	<div id="mySidenav" class="sidenav">
		  <a href="#" class="closebtn" onclick="closeNav()">&times;</a>
		  <a href="resumes.php">Create Resume</a>
		  <a href="viewresume.php">View Resume</a>
		  <a href="#">Edit Resume</a>

	</div>
	

	</div>
	</div>

	<div class="fcontainer">

	<div class="form_head">
		<div class="form_title">

			<div class="name_cont">
					<h2 class="form-title-1"><?php echo $_SESSION['name']; ?></h2>
					<h2 class="form-title-1"><?php echo $_SESSION['defdesig']; ?></h2>
			</div>
			<div class="form_image">
				<?php echo $_SESSION['imag'];?>
			</div>

		</div>

	<form class="form_containers" method="POST">
		
		<div class="left">

			<h1>Contact:-</h1>
			<div class="con_info">
				<p><?php echo $_SESSION['dob']; ?></p>
				<p style="overflow: hidden;"><?php echo $_SESSION['email']; ?></p>
				<p><?php echo $_SESSION['ph_no']; ?></p>
				<address style="font-size: 20px;overflow-wrap: anywhere;text-align:left">
				<?php echo $_SESSION['address']; ?>
				</address>
			</div>
			<h1 style="padding-top:15px;">Language Known:-</h1>
			<div class="con_infos">	
				<ol style="padding-left: 35px;font-size:23px">
					<li style="padding-top: 15px;"><?php echo $_SESSION['lan1']; ?></li>
					<li style="padding-top: 15px;"><?php echo $_SESSION['lan2']; ?></li>
					<li style="padding-top: 15px;"><?php echo $_SESSION['lan3']; ?></li>
				</ol>
			</div>
			</div>

			<div class="right">
				<div class="em_detail">
					<h2>Objective:-</h2>
					<p style="text-indent:30px;font-size: 20px;line-height:3vh;">
						<?php echo $_SESSION['object'];?>
					</p>

					<h2 style="padding-bottom:20px ;">Education Details:-</h2>
					<table >
							<tr style="padding-top:50px ;">
								<td>SSLC</td>
								<td><?php echo $_SESSION['sslcinst']; ?></td>
								<td><?php echo $_SESSION['sslcpercen']; ?>%</td>
							</tr>
							<tr>
								<td>HSC</td>
								<td><?php echo $_SESSION['hscinst']; ?></td>
								<td><?php echo $_SESSION['hscpercen']; ?>%</td>
							</tr>
							<tr>
								<td><?php echo $_SESSION['degree']; ?></td>
								<td><?php echo $_SESSION['deginst']; ?></td>
								<td><?php echo $_SESSION['degpercen']; ?>%</td>
							</tr>
					</table>

					<h2>Experience Details:-</h2>
					<div style="font-size: 23px;padding-left:50px;">
						<p style="padding-top:2% ;">Organization : <?php echo $_SESSION['organ']; ?></p>
						<p style="padding-left:10px ;">Designation : <?php echo $_SESSION['designa']; ?></p>
						<p style="padding-left:78px ;">From : <?php echo $_SESSION['exfrom']; ?></p>
						<p style="padding-left:107px ;">To : <?php echo $_SESSION['exto']; ?></p>
					</div>

					<h2>Professional Summary:-</h2>
					<p style="text-indent:10%;font-size: 20px;line-height:3vh;">
					<?php echo $_SESSION['profsumm']; ?>
					</p>

					<h2>Hobbies:-</h2>
					<p style="font-size: 23px;padding:13px 50px;">
					<?php echo $_SESSION['hob1']; ?>,
					<?php echo $_SESSION['hob2']; ?>,
					<?php echo $_SESSION['hob3']; ?>
					</p>

					<h2>Programming Skills:-</h2>
					<p style="font-size: 23px;padding:13px 50px;">
						<?php echo $_SESSION['proskill1']; ?>,
						<?php echo $_SESSION['proskill2']; ?>,
						<?php echo $_SESSION['proskill3']; ?>
					</p>
					
					<h2>Other Skills:-</h2>
					<p style="font-size: 23px;padding:13px 50px;">
						<?php echo $_SESSION['otherskill']; ?>
					</p>
					
					<h2>Declaration:-</h2>
					<p style="text-indent:10%;font-size: 20px;line-height:3vh;">I hereby declare that all the information provided above is accurate to the best of my knowledge.</p>
				
					<h2>Place:- <span style="font-size: 22px;"><?php echo $_SESSION['place']; ?></span></h2>
					<h2> Date:- <span style="font-size: 22px;"><?php echo $_SESSION['todaydate']; ?></span></h2>
				</div>
			</div>
		</div>
	</form>
	<footer>Copyrights@2022</footer>
</div>

	<script>
		document.getElementById('accls').addEventListener('click', closeNav);
		document.getElementById('rescls').addEventListener('click', closeNav2);

		function openNav() {
			document.getElementById("mySidenav").style.width = "300px";
		}
		function openNav2() {
			document.getElementById("mySidenav2").style.width = "300px";
		}

		function closeNav() {
			document.getElementById("mySidenav").style.width = "0";
		}
		function closeNav2() {
			document.getElementById("mySidenav2").style.width = "0";
		}
	</script>

</body>
</html>