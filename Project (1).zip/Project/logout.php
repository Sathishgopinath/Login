<?php

session_start();
unlink($_SESSION["location"]);
session_destroy();
header("location:index.php")

?>