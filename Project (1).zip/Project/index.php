<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <!-- <link rel="stylesheet" href="indexs.css"> -->

    <?php include 'Login_back.php';?>
    <?php include 'Signup_back.php';?>
    

 <style>
        
*{
    margin: 0;
    padding: 0;
    font-family: sans-serif;
}
body
{
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(to top , #292929,#3939);
    /*background: gray;*/
}
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px;
  /*background-color: teal;*/
  color: #fff;
  position:fixed;
  width: 100%;
  z-index: 1;
  top: 0;
 }
 img{
  border-radius: 10%;
  /*border: none;
  outline: none;*/
  padding-left:20px ;
}

 .anger{
    color: orange;
}
section
{
    display: flex;
    align-items: center;
    position: relative;
    justify-content: space-around;
    height: 500px;
    width: 850px;
    padding: 10px;
    z-index: 100;
    overflow: hidden;
    /* border: 0.5px solid #393939; */
    border-radius: 0 60px 0 60px;
    box-shadow: inset 5px 5px 10px #29292991,
    inset -5px -5px 10px #393939,
    10px 10px 30px rgba(0, 0, 0, 0.493),
    -10px -10px 20px rgba(0, 0, 0, 0.37);
}
.heading{
    text-decoration:underline yellowgreen 3px;
}
.btn
{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 80px;
    flex-direction: row;
}
.btn button
{
    border: none;
    outline: none;
    margin: 10px;
    height: 40px;
    width: 90px;
    border-radius: 10px;
    letter-spacing: 2px;
    font-size: 0.90em;
    font-weight: bolder;
    background: #fff;
    color: #0084ff;
    box-shadow: 0 .25em .25em -.125em rgba(0,0,0,.25), 0 .5em 1.25em rgba(0,0,0,.5);
    cursor:pointer ;
}
.btn button:hover{
    letter-spacing: 3px;
    font-size: 0.92em;
    transition: 0.2s;
    box-shadow: white;
}

.gn
{
    position: relative;
    transition: 2s;
    height: 100%;
    width: 300px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    color: #fff;
}

#slide1
{
    background: blueviolet;
    box-shadow: inset 10px 10px 10px #29292954,
    inset -10px -10px 10px #29292954,
    5px 5px 15px #292929;
    height: 490px;
    transition: 1.5s;
    width: 410px;
    position: absolute;
    right: 50%;
    display: flex;
    align-items: center;
    text-align: center;
    justify-content: space-around;
    flex-direction: column;
    color: antiquewhite;
    border-radius: 0 60px 0 60px;
    overflow: hidden;
}

#txt-h2,
#txt-p
{
    user-select: none;
}

#slide1.left
{
    right: 27px;
    transition: 1.5s;
    box-shadow:inset 10px 10px 10px #29292954,
    inset -10px -10px 10px #29292954,
     -5px 5px 15px #292929;
}
.input
{
    position: relative;
    margin: 15px;
    width: 90%;
    font-size: 25px;
    border: none;
    outline: none;
    padding: 10px 10px;
    text-align: center;
    background: transparent;
    border-bottom: 2px solid white;
}

::placeholder{
    text-align: center;
    text-transform: uppercase;
    font-size: 16px;
    color: white;
    
}
::placeholder:hover{
    
    font-size: 0.5em;
    transition: 1s;
}

input[type=submit]{
    border: none;
    outline: none;
    margin: 15px;
    height: 40px;
    width: 90px;
    border-radius: 10px;
    letter-spacing: 1px;
    font-size: 0.90em;
    font-weight: bolder;
    background: #fff;
    color: #0084ff;
    box-shadow: 0 .25em .25em -.125em rgba(0,0,0,.25), 0 .5em 1.25em rgba(0,0,0,.5);
    cursor:pointer ;

}
input{
    color: white;
}

input[type=submit]:hover{
    letter-spacing: 3px;
    font-size: 0.92em;
    transition: 0.2s;
    box-shadow: white;
}


@keyframes txt {
    0%
    {
        color: #0084ff;
        transform: translateY(-150px);
    }
    to
    {   
        transform: rotate3d(20,1,1,360deg);
        color: #fff;
    }
}
@keyframes txt2 {
    0%
    {
        color: #0084ff;
        transform: translateY(250px);
    }
    to
    {
       
        transform: rotate3d(-20,1,1,360deg);
        color: #fff;
    }
}
input:invalid {
  color: black;
  font-size: 25px;
}
h2{
    padding-bottom: 10px;
}
    </style>

</head>
<body>

    <script>
    if ( window.history.replaceState ) {
      window.history.replaceState( null, null, window.location.href );
    }
    </script>

    <nav class="navbar">
        <div>
            <img src="rlogo1crop.png" width="60px" height="60px" style="filter: drop-shadow(0 0 0.75rem white);">
        </div>
        
    </nav>

    
    <section>

        <!-- LOGIN FORM -->

        <form class="l gn" id="lgn"  method="post">

            <h1 class = "heading">Login</h1>
            
            <input type="email" class="input" name="lemail" required placeholder="Username" value=""> 
        
            <input type="password" class="input" name="lpasswd" required placeholder="Password" value="">

            <a href="forget_pass.php" class="anger" >Forgot password?</a> 

            <input type="submit" class="button" name="lsubmit" value="LOGIN" onclick="myFunction()"><br><br>

        </form>


        <!-- SIGNUP FORM -->

        <form class="s gn hde" id="sgn"  method="post">

            <h2 class = "heading"> Sign UP </h2>

            <input type="email" class="input" name="semail" required placeholder="Email" value="" autocomplete="off">

            <input type="password" class="input" name="spasswd" required placeholder="Password" value="">

            <input type="password" class="input" name="srepasswd" required placeholder="Retype Password" value="">
            <span style="color: red;"><?php echo $srepasswderr;?></span>

            <input type="text" class="input" name="sphno" required placeholder="Phone no" pattern="^[0-9]{10,12}$" value="" >

            <input type="submit" class="button" name="ssubmit" value="SUBMIT" onclick="myFunction()">  

        </form>
        <div id="slide1">
            <div class="txt" id="stx">
                <h2 id="txt-h2">Join Our Community<br>Now!</h2><br><br><br>
                <h2 id="txt-tem"><?php echo $ssuccess;?></h2>
                <h2 id="txt-tem"><?php echo $main;?></h2>
            </div>
            <div class="btn"> 
                <p id="txt-p">Have an account!</p>
                <button id="tgl" onclick="login()">Log in</button>
            </div>
        </div>
        
        
    </section>

    
    <script>
        function myFunction() {
            document.getElementsByClassName('input').placeholder = "Required";
        }

    </script>


    <script>

        console.log(<?php echo $get;?>);
        console.log(<?php echo $main;?>);
        console.log(<?php echo $ch_pass;?>);
        console.log(<?php echo $ssuccess;?>);
        console.log(<?php echo $srepasswderr;?>);

    </script>

    <script>
        let slide1 = document.getElementById('slide1');
        let tgl = document.getElementById('tgl');
        let h2t = document.getElementById('txt-h2');
        let h2su = document.getElementById('txt-tem');
        let pt = document.getElementById('txt-p');
        let stx = document.getElementById('stx');

        function login()

        {
            slide1.classList.toggle('left');
            if( tgl.innerText === "Log in")
            {
                tgl.innerText = "Sign in";
                h2t.innerText = "Welcome Back !";
                pt.innerText = "Not having account";
                stx.style = " animation: txt 3s ease forwards; animation-iteration-count: initial;";
            }
            else
            {
                tgl.innerText = "Log in";
                h2t.innerHTML = "Join Our Community <br> Now!";
                pt.innerText = "Have an account!";
                h2su.innerText = "";
                stx.style = " animation: txt2 3s ease forwards; animation-iteration-count: initial;";
            }
          
        }

        

    </script>



</body>
</html>