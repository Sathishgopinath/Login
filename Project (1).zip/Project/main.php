<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Main Page</title>

<style>
* {
  margin: 0;
  padding: 0;
  font-family: Garamond, serif;
  box-sizing: border-box;
}

body {
 font-family: cursive;
 background: url("resumeimg.jpg");

}
a {
 text-decoration: none;
}
li {
 list-style: none;
}
.navbar {
 display: flex;
 align-items: center;
 justify-content: space-between;
 padding: 20px;
 background-color: teal;
 color: #fff;
 height: 10%;
}
.nav-links a {
 color: #fff;
}
/* LOGO */
.logo {
 font-size: 32px;
}
/* NAVBAR MENU */
.menu {
 display: flex;
 gap: 1em;
 font-size: 18px;
}
.menu li:hover {
    letter-spacing: 3px;
    text-align: center;
    font-size: 1.3em;
    transition: 0.2s;
    box-shadow: white;
}
.menu li {
 padding: 5px 14px;
 font-size: 25px;
 cursor:pointer;
}

/* DROPDOWN MENU */
.services {
 position: relative; 
}
.dropdown {
 background-color: rgb(1, 139, 139);
 padding: 1em 0;
 position: absolute; /*WITH RESPECT TO PARENT*/
 display: none;
 border-radius: 8px;
 top: 35px;
}

.dropdown li {
 padding: 0.5em 1em;
 width: 8em;
 text-align: center;
}
.dropdown li:hover {
    text-align: center;
    font-size: 1em;
    transition: 0.2s;
    box-shadow: white;

}
.services:hover .dropdown {
 display: block;
}


.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 0;
  top: 13.5%;
  left: 0;
  background-color: teal;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 90px;
  border-top: 1px solid white;
  /* background: transparent; */

}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: white;
  display: block;
  transition: 0.3s;
  margin-top: 10px;
}

.sidenav a:hover {
 
    font-size: 27px;
    transition: 0.s;
    box-shadow: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}
.uname{
  float: right;
  margin-right:10px ;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.img_con {
  position: absolute;
  top: 30%;
  font-size: 50px;
  font-weight: bolder;
  text-align: center;
  color: #4d0028;
/*  display: flex;
  align-items: center;*/
  width: 90%;
  left: 5%;
/*  box-shadow: 0 .25em .25em -.125em rgba(0,0,0,.25), 0 .5em 1.25em rgba(0,0,0,.5);
  transform: translate(-50%, -50%);*/
}
</style>
</head>
<body>

<?php
  session_start();
	if (!isset($_SESSION['lemail'])){

		header("location:index.php?sass=''");
	}


?>	


 <body id="main">
 <div class="container">
    <nav class="navbar">
    <!-- LOGO -->
    <div>
          <img src="rlogo1crop.png" width="60px" height="60px" style="filter: drop-shadow(0 0 0.75rem white);">
          <div class="img_con"><p >Make a perfect resume in 2022 and get your dream job by using our free resume builder</p></div>
    </div>
    <!-- NAVIGATION MENU -->
      <ul class="nav-links">
        <div class="menu">
          <li><a href="#">Home</a></li>
          <li><a href="#" id = "rescls" onclick="openNav()">Resume</a></li>
          <li><a href="#" id = "accls" onclick="openNav2()">Account Details </a></li>
          <li><a href="#">About</a></li>

              <li><a href="logout.php">Logout?</a></li>
      
        </div>
      </ul>
    </nav>

  <div class="container-page">
    
    <div id="mySidenav" class="sidenav">
        <a href="#" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="resumes.php">Create Resume</a>
        <a href="viewresume.php">View Resume</a>
        <a href="#">Edit Resume</a>

    </div>

    <div id="mySidenav2" class="sidenav">
        <a href="#" class="closebtn" onclick="closeNav2()">&times;</a>
        <a href="">Account Details</a>
        <a href="change_pass.php">Change Password</a>
        <a href="#">Delete Account</a>

    </div>

	</div>

	</div>

<h2 class = "uname" >
    <?php  
        $string = $_SESSION['lemail'];
        $newString = substr($string, 0, strpos($string, "@"));
        echo "Welcome ".strtoupper($newString);
    ?>
  </h2>

	<script>
document.getElementById('accls').addEventListener('click', closeNav);
document.getElementById('rescls').addEventListener('click', closeNav2);

function openNav() {
  document.getElementById("mySidenav").style.width = "300px";
}
function openNav2() {
  document.getElementById("mySidenav2").style.width = "300px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
function closeNav2() {
  document.getElementById("mySidenav2").style.width = "0";
}
</script>
 </body>
</html>




</body>
</html>





























