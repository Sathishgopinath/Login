<?php

    $semailerr=$spasswderr=$srepasswderr=$sphnoerr="";
    $semail=$spasswd=$srepasswd=$sphno=$ssuccess="";


    function database($demail,$dpasswd,$drepasswd,$dphno){
                        
        $sfile = fopen("file.txt", "a+");
        
        if(!$sfile) {
            $sresult = "Error : Unable to open database <br>";
        } 
        else 
        {
            $sresult = "file opened successfully <br>";
            $ll=0;
            while ($sdata = fgets($sfile))
            {
                
                $sexploded_data = explode(" ", $sdata);
                if ($sexploded_data[0] == $demail)
                {
                    $ll=1;
                    $sresult = "Your account already exist";
                    break;
                }
            }

            if ($ll == 0)
            {
                    fwrite($sfile, "$demail $dpasswd $drepasswd $dphno\n");
                    $sresult = "Your account added successfully";
                    echo "<script>window.onload=function(){
                        document.getElementById('tgl').click();
                      };</script>";
            }

        }
        
        fclose($sfile);   
        return $sresult;
    }


    if (isset($_POST['ssubmit'])){

        if (empty ($_POST["semail"])) {  
              $semailerr = "Email is required";  
        }

        elseif(empty ($_POST["spasswd"])) {  
             $spasswderr = "Password is required"; 
        }

        elseif(empty ($_POST["srepasswd"])) {  
            $srepasswderr = "Confirm password is required";

        }

        elseif(empty ($_POST["sphno"])) {  
            $sphnoerr = "Password is required";
        }

        else { 

            if (($_POST["srepasswd"]) === ($_POST["spasswd"])){
                
                $semail = strtolower($_POST["semail"]);
                $spasswd = $_POST["spasswd"];
                $srepasswd = $_POST["srepasswd"];
                $sphno = $_POST["sphno"];

                $ssuccess = database($semail,$spasswd,$srepasswd,$sphno);
            }
            else{
                $srepasswderr = "Confirm Password & retype password is not same";
            }

        }  
        
    }


?>