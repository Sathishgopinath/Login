 <?php

        session_set_cookie_params(0);
        session_start();

        if (isset($_GET['result'])){

            $main = $_GET['result'];
        }else{

            $main=null;
        }

        if (isset($_GET['sass'])){

            $main = "Please Login to access";
        }else{

            $main=null;
        }

        if (isset($_GET['ch_pass'])){

            $main = $_GET['ch_pass'];
        }else{

            $main = null;
        }

    ?>

<?php
     echo "<script>window.onload=function(){
        document.getElementById('tgl').click();
      };</script>";

    $lemail=$lpasswd=$lsuccess=$re="";
    $lemailerr=$lpasswderr="";

	function getdata($femail,$fpasswd){

		$lfile = fopen("file.txt", "r");

		if(!$lfile ) {
		$lresult = "Error : Unable to open database <br>";
		} 
		else {
			$lresult="";
            $cc=0;
			while($ldata = fgets($lfile)){

				$lexploded_data = explode(" ", $ldata);

				#print_r($lexploded_data);
				
				#$hashpass = password_verify($fpasswd, $lexploded_data[1]);

				if ($femail == $lexploded_data[0]){
                    $cc=1;
					if (($femail === $lexploded_data[0]) && ($fpasswd === $lexploded_data[1]))
                    {
						$lresult = "Login successfully";
                        
						$_SESSION['lemail']=$femail;
						header('Location:main.php');
						break;
					}
					else{
                        echo "<script>window.alert('Password incorrect');</script>";
                         
                        break;
					}
				}
					
			}
            if ($cc == 0){
                echo "<script>window.alert('Mail address incorrect');</script>";
            }
			
		fclose($lfile);
		return $lresult;

	}

	}

    if (isset($_POST['lsubmit'])){

        if (empty ($_POST["lemail"])) {  
            $emailerr = "Email is required";  
        }

        elseif(empty ($_POST["lpasswd"])) {  
            $passwderr = "Password is required"; 
        }

    else{

        $lemail = strtolower($_POST["lemail"]);
        $lpasswd = $_POST["lpasswd"];

        $lsuccess = getdata($lemail,$lpasswd);

    }

    }


?>