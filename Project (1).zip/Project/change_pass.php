<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="indexs.css">

	<?php include 'Login_back.php';?>
    <?php include 'Signup_back.php';?>
    
<style>
    .navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px;
  /*background-color: teal;*/
  color: #fff;
  position:fixed;
  width: 100%;
  z-index: 1;
  top: 0;
 }
 img{
  border-radius: 10%;
  /*border: none;
  outline: none;*/
  padding-left:20px ;
}

    
 </style>

</head>
<body>

<?php
	// session_set_cookie_params(0);
	// session_start();

	if (!isset($_SESSION['lemail'])){

		header("location:trans.php?sass=Please Login to access");

	}


	$email=$old_pass=$success="";
	$emailerr=$old_passerr=$newpasswderr="";

	if (isset($_POST['submit'])){

	    if (empty ($_POST["email"])) {  
	         $emailerr = "Email is required";  
	    }

	    elseif(empty ($_POST["newpasswd"])) {  
	     	 $old_passerr = "Old password is required"; 
		}

		elseif(empty ($_POST["old_pass"])) {  
		     $newpasswderr = "Password is required"; 
		}

		else{

			$chemail = $_POST["email"];
			$chold_pass = $_POST["old_pass"];
		    $chnewpasswd = $_POST["newpasswd"];
		    #$newpasswd1 = $_POST["newpasswd"];
		    
		    $ffile = fopen("file.txt", "a+");

            if(!$ffile ) {
                $success = "Error : Unable to open file <br>";
            } 
		    else {

		       while($ldata = fgets($ffile)){

                $lexploded_data = explode(" ", $ldata);

		       	if ($lexploded_data[0] == $chemail){

			  		if (($lexploded_data[0] == $chemail) && ($lexploded_data[1] == $chold_pass)){

                        $lexploded_data[1] = $chnewpasswd;
                        $lexploded_data[2] = $chnewpasswd;

                        file_put_contents("file.txt", "\n$lexploded_data[0] $lexploded_data[1] $lexploded_data[2] $lexploded_data[3]\n",FILE_APPEND);
                        
                        $rows = file("file.txt");    
                        $blacklist = $ldata;
                        
                        foreach($rows as $key => $row) {
                            if(preg_match("/($blacklist)/", $row)) {
                                unset($rows[$key]);
                            }
                        }
                        file_put_contents("file.txt", implode("\n", $rows));

                        $str=file_get_contents("file.txt");
                        $str = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $str);
                        
                        file_put_contents("file.txt", "$str");

				   		$success = "Your password changed successfully";
				   		header("Location:main.php");
				   		break;

				  	}
				  	else{

		  				$success = "Your Old password is incorrect";
		  				break;
		  			}
				}

		  		else{

		  			$success = "Your Email is incorrect";	  			
		  		}
		}
		fclose($ffile);
	}
	
  }
}

?>
	<script>
	if ( window.history.replaceState ) {
	  window.history.replaceState( null, null, window.location.href );
	}
	</script>

    <nav class="navbar">
    <div>
        <img src="rlogo1crop.png" width="60px" height="60px" style="filter: drop-shadow(0 0 0.75rem white);">
    </div>
        
    </nav>

<!-- FORGOT PASSWORD FORM -->
<section>
	<form class="s gn hde" id="sgn" method="POST">

	<h2> Change password </h2>

		<input type="email" class="input" required name="email" placeholder="Email"> 
		<!-- <span class="error"> <?php echo $emailerr; ?> </span> -->

		<input type="password" class="input" required name="old_pass" placeholder="Old Password"> 
		<!-- <span class="error"> <?php echo $old_passerr; ?> </span> -->

		<input type="password" class="input" required name="newpasswd" placeholder="New Password"> 
		<!-- <span class="error"> <?php echo $newpasswderr; ?> </span> -->

		<input type="submit" class="button" name="submit" value="SUBMIT"> 

	</form>

	<form class="s gn hde" id="sgn">
	</form>

	<div id="slide1" class="left">
		<div class="txt" id="stx">
			<h2 id="txt-h2">Join Our Community<br>Now!</h2><br><br><br>
			<h2 id="txt-tem"><?php echo $success;?></h2>
		</div>
		<div class="btn"> 
			<p id="txt-p">Have an account!</p>
			<button id="tgl" >Log in</button>
		</div>
	</div>

</section>


</body>
</html>