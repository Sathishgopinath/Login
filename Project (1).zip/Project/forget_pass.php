<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>

    <link rel="stylesheet" href="indexs.css">
<style>
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px;
  /*background-color: teal;*/
  color: #fff;
  position:fixed;
  width: 100%;
  z-index: 1;
  top: 0;
 }
 img{
  border-radius: 10%;
  /*border: none;
  outline: none;*/
  padding-left:20px ;
}
 
 </style>
</head>
<body>

<?php

	$email=$ph_no=$newpasswd=$success="";
	$emailerr=$ph_noerr=$newpasswderr="";

	if (isset($_POST['submit'])){

	    if (empty ($_POST["email"])) {  
	         $emailerr = "Email is required";  
	    }

	    elseif(empty ($_POST["newpasswd"])) {  
	     	 $ph_noerr = "Old password is required"; 
		}

		elseif(empty ($_POST["ph_no"])) {  
		     $passwderr = "Password is required"; 
		}

		else{

			$email = $_POST["email"];
		    $newpasswd = $_POST["newpasswd"];
		    $repasswd = $_POST["newpasswd"];
		    $ph_no = $_POST["ph_no"];

            $ffile = fopen("file.txt", "a+");

            if(!$ffile ) {
                $success = "Error : Unable to open database <br>";
            } 
		    else {
     
		       while($ldata = fgets($ffile)){

                $lexploded_data = explode(" ", $ldata);

		       	if ($lexploded_data[0] == $email){

			  		if (($lexploded_data[0] == $email) && ($lexploded_data[3] === $ph_no)){

                        $lexploded_data[1] = $newpasswd;
                        $lexploded_data[2] = $repasswd;

                        file_put_contents("file.txt", "\n$lexploded_data[0] $lexploded_data[1] $lexploded_data[2] $lexploded_data[3]\n",FILE_APPEND);
                        
                        $rows = file("file.txt");    
                        $blacklist = $ldata;
                        
                        foreach($rows as $key => $row) {
                            if(preg_match("/($blacklist)/", $row)) {
                                unset($rows[$key]);
                            }
                        }
                        file_put_contents("file.txt", implode("\n", $rows));

                        $str=file_get_contents("file.txt");
                        $str = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $str);
                        
                        file_put_contents("file.txt", "$str");

				   		$success = "Your password changed successfully";
                        
                        header("Location:index.php");

				   		break;

				  	}
				  	else{

		  				$success = "Your phone number is incorrect";
		  				break;
		  			}
				}

		  		else{

		  			$success = "Your Email is incorrect";	  			
		  		}
		}
		fclose($ffile);
	}
	
	
  }
}

?>

	<script>
	if ( window.history.replaceState ) {
	  window.history.replaceState( null, null, window.location.href );
	}
	</script>
    
    <nav class="navbar">
    <div>
        <img src="rlogo1crop.png" width="60px" height="60px" style="filter: drop-shadow(0 0 0.75rem white);">
    </div>
        
    </nav>

    
    <section>

        <!-- FORGOT PASSWORD FORM -->
        <form class="s gn hde" id="sgn" >
        </form>

        <form class="s gn hde" id="sgn"  method="POST">
        <h2> Forgot password </h2>

            <input type="email" class="input" name="email" required placeholder="Email"> 

            <input type="text" class="input" name="ph_no" required placeholder="Phone Number" pattern="^[0-9]{10,12}$"> 

            <input type="password" class="input" name="newpasswd" required placeholder="New Password"> 

            <input type="submit" class="button" name="submit" value="SUBMIT">  
           
        </form>

        <div id="slide1">
            <div class="txt" id="stx">
                <h2 id="txt-h2">Join Our Community<br>Now!</h2><br><br><br>
                <h2 id="txt-tem"><?php echo $success;?></h2>
            </div>
            <div class="btn"> 
                <p id="txt-p">Have an account!</p>
                <button id="tgl"><a href="index.php" style="text-decoration: none;">Log in</a></button>
            </div>
        </div>
        
        
    </section>
    
    <script>
        function myFunction() {
            document.getElementsByClassName('input').placeholder = "Required";
        }

    </script>


    <script>

        console.log(<?php echo $get;?>);
        console.log(<?php echo $main;?>);
        console.log(<?php echo $ch_pass;?>);
        console.log(<?php echo $ssuccess;?>);
        console.log(<?php echo $srepasswderr;?>);

    </script>

    <script>
        let slide1 = document.getElementById('slide1');
        let tgl = document.getElementById('tgl');
        let h2t = document.getElementById('txt-h2');
        //let h2su = document.getElementById('txt-tem');
        let pt = document.getElementById('txt-p');
        let stx = document.getElementById('stx');
    </script>


</body>
</html>