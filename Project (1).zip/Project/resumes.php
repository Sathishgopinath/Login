<!DOCTYPE html>
<html lang="en">
<head>
	<title>Create resume</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="resumes.css">

<style >
	.sidenav {
   height: 100%;
   width: 0;
   position: fixed;
   z-index: 1;
   top: 13.5%;
   left: 0;
   background-color: teal;
   overflow-x: hidden;
   transition: 0.5s;
   padding-top: 90px;
   border-top: 1px solid white;
   /* background: transparent; */
   /* opacity: 0.7; */
 
 }
 .uname{
  float: right;
  margin-right:10px ;
}
</style>
</head>
<body>



<?php
	session_start();
	if (!isset($_SESSION['lemail'])){

		header("location:index.php?sass=''");
	}

function rasmname(){
    $dirname = "image_folder/";
    $images = glob($dirname."*.jpg");
    foreach($images as $image) {
    $GLOBALS['a'] = '<img src="'.$image.'" width="250px" 
    height="250px"/><br/>';

    #echo $a;
     }
   }


	if (isset($_POST['submit']))
	{		
		$_SESSION['name'] = $_POST['name'];
		$_SESSION['defdesig'] = $_POST['defdesig'];
		$_SESSION['name'] = $_POST['name'];
		$_SESSION['dob'] = $_POST['dob'];
		$_SESSION['email'] = $_POST['email'];
		$_SESSION['ph_no'] = $_POST['ph_no'];
		$_SESSION['address'] = $_POST['address'];

		$_SESSION['object'] = $_POST['object'];

		$_SESSION['sslcinst'] = $_POST['sslcinst'];
		$_SESSION['sslcpercen'] = $_POST['sslcpercen'];

		$_SESSION['hscinst'] = $_POST['hscinst'];
		$_SESSION['hscpercen'] = $_POST['hscpercen'];

		$_SESSION['degree'] = $_POST['degree'];
		$_SESSION['deginst'] = $_POST['deginst'];
		$_SESSION['degpercen'] = $_POST['degpercen'];

		$_SESSION['lan1'] = $_POST['lan1'];
		$_SESSION['lan2'] = $_POST['lan2'];
		$_SESSION['lan3'] = $_POST['lan3'];
		
		$_SESSION['organ'] = $_POST['organ'];
		$_SESSION['designa'] = $_POST['designa'];
		$_SESSION['profsumm'] = $_POST['profsumm'];
		$_SESSION['exfrom'] = $_POST['exfrom'];
		$_SESSION['exto'] = $_POST['exto'];

		$_SESSION['profsumm'] = $_POST['profsumm'];

		$_SESSION['hob1'] = $_POST['hob1'];
		$_SESSION['hob2'] = $_POST['hob2'];
		$_SESSION['hob3'] = $_POST['hob3'];

		$_SESSION['proskill1'] = $_POST['proskill1'];
		$_SESSION['proskill2'] = $_POST['proskill2'];
		$_SESSION['proskill3'] = $_POST['proskill3'];
		$_SESSION['otherskill'] = $_POST['otherskill'];

		$_SESSION['place'] = $_POST['place'];
		$_SESSION['todaydate'] = $_POST['todaydate'];

		$ImageName = $_FILES['photo']['name'];
		$fileElementName = 'photo';
		$path = 'image_folder/'; 
		$_SESSION["location"] = $path . $_FILES['photo']['name'];
		#echo $location;
		move_uploaded_file($_FILES['photo']['tmp_name'], $_SESSION["location"]); 
		rasmname();
		$_SESSION['imag'] = $a;
		#header("location:viewresume.php?sass=Your details stored succesfully");
}


?>

<script>
    if ( window.history.replaceState ) {
      window.history.replaceState( null, null, window.location.href );
    }
</script>

<div class="container">
    <nav class="navbar">
    <!-- LOGO -->
    <div>
		<img src="rlogo1crop.png" width="60px" height="60px" style="filter: drop-shadow(0 0 0.75rem white);">
	</div>
    <!-- NAVIGATION MENU -->
      <ul class="nav-links">
        <div class="menu">
          <li><a href="#">Home</a></li>
          <li><a href="#" id = "rescls" onclick="openNav()">Resume</a></li>
          <li><a href="#" id = "accls" onclick="openNav2()">Account Details </a></li>
          <li><a href="#">About</a></li>

              <li><a href="logout.php">Logout?</a></li>
      
        </div>
      </ul>
    </nav>

	<div class="container-page">
		
		<div id="mySidenav" class="sidenav">
			<a href="#" class="closebtn" onclick="closeNav()">&times;</a>
			<a href="#">Create Resume</a>
			<a href="viewresume.php">View Resume</a>
			<a href="#">Edit Resume</a>

		</div>

		<div id="mySidenav2" class="sidenav">
			<a href="#" class="closebtn" onclick="closeNav2()">&times;</a>
			<a href="">Account Details</a>
			<a href="change_pass.php">Change Password</a>
			<a href="#" disabled >Delete Account</a>

		</div>

	</div>

	</div>

<h2 class = "uname" >
    <?php  
        $string = $_SESSION['lemail'];
        $newString = substr($string, 0, strpos($string, "@"));
        echo "Welcome ".strtoupper($newString);
    ?>
</h2>


	<div class="fcontainer">

		<div class="form_head">
			<div class="form-title">
				<h2 class="form-title-1">
					Create your own resume
				</h2>
			</div>

			<form class="form_container" method="POST" enctype="multipart/form-data">
				
				<div class="wrap-input">
					<label class="label">Full Name:</label>
					<input class="input" type="text" name="name" required placeholder="Enter full name" pattern="[a-zA-Z \.]*" title="Enter name">
				</div>
				<div class="wrap-input">
					<label class="label">Designation:</label>
					<input class="input" type="text" name="defdesig" required placeholder="Designation" pattern="[a-zA-Z ]*">
				</div>

				<div class="wrap-input">
					<label class="label">Date_of_birth:</label>
					<input class="input" type="date" name="dob" required placeholder="Enter Date_of_birth" style="color:white;font-size: 22px;">
					
				</div>

				<div class="wrap-input">
					<label class="label">Email:</label>
					<input class="input" type="email" name="email" required placeholder="Enter email addess">

				</div>

				<div class="wrap-input">
					<label class="label">Phone_no:</label>
					<input class="input" type="text" name="ph_no" required placeholder="Enter phone number" pattern="^[0-9]{10,12}$">
					
				</div>

				<div class="wrap-input">
					<label class="label">Address:</label>
					<textarea class="input" name="address" required placeholder="Your Address..."></textarea>
					
				</div>

				<div class="wrap_inputed" style="border:0.5px solid white;">

					<label class="label" style="top: auto;">Education Details:</label>
						<table>
							<input class="inputed" type="text" disabled  value="SSLC : -" style="font-size:20px;border:none;text-align:center;">
							<input class="inputed" type="text" required name="sslcinst" placeholder="Institution name" pattern="[a-zA-Z \.]*" style="text-align: center;">
							<input class="inputed" type="text" required name="sslcpercen" placeholder="Percentage" 
								style="text-align: center;" 
								pattern="[0-9]{1,2}(\.[0-9]{1,2})?%?" 
								title="This must be a number with up to 2 decimal places and/or %">

							<input class="inputed" type="text" disabled value="HSC : -" style="font-size:20px;border:none;text-align:center;">
							<input class="inputed" type="text" required name="hscinst" placeholder="Institution name" pattern="[a-zA-Z \.]*" style="text-align: center;">
							<input class="inputed" type="text" required name="hscpercen" placeholder="Percentage" 
								style="text-align: center;" 
								pattern="[0-9]{1,2}(\.[0-9]{1,2})?%?" 
								title="This must be a number with up to 2 decimal places and/or %">

							<br><br>
							<input class="inputed" type="text" required name="degree" placeholder="Enter your Degree" pattern="[a-zA-Z \.]*" style="text-align: center;">
							<input class="inputed" type="text" required name="deginst" placeholder="Institution name" pattern="[a-zA-Z \.]*" style="text-align: center;">
							<input class="inputed" type="text" required name="degpercen" placeholder="Percentage" 
								style="text-align: center;" 
								pattern="[0-9]{1,2}(\.[0-9]{1,2})?%?" 
								title="This must be a number with up to 2 decimal places and/or %">

						</table>
				</div>

				<div class="wrap-input" style="border-bottom:none;">
					<label class="label">Languages Known:</label>
					
					<input class="inputla" type="text" required name="lan1" placeholder="Language 1" style="font-size: 20px;" pattern="^[a-zA-Z \,]*">
					<input class="inputla" type="text" required name="lan2" placeholder="Language 2" style="font-size: 20px;" pattern="^[a-zA-Z \,]*">
					<input class="inputla" type="text" name="lan3" placeholder="Language 3" style="font-size: 20px;" pattern="[a-zA-Z \,]*">
					
				</div>

				<div class="wrap-input">
					<label class="label">Objective:</label>
					<textarea class="input" name="object" required placeholder="Your Comment..."></textarea>
					
				</div>
				<div class="wrap_inputex">
					<label class="label" >Experience Details:</label>

					<input class="input" type="text" required name="organ" placeholder="Organization" style="border-bottom: 2px solid white;" pattern="[a-zA-Z ]*" ><br>
					<input class="input" type="text" required name="designa" placeholder="Designation" style="border-bottom: 2px solid white;" pattern="[a-zA-Z ]*"><br>

					<table>
							<span style="font-size: 25px;color: white;">From: </span>
							<input class="inputex" type="date" required name="exfrom" style="font-size: 20px;border-bottom:2px solid white;color:white;">
							<span style="font-size: 25px;color: white;padding-left:25px;">To: </span>
							<input class="inputex" type="date" required name="exto" style="font-size: 20px;border-bottom:2px solid white;color:white;">
					</table>
					
				</div>
				<div class="wrap-input">
					<label class="label">Professional Summary:</label>
					<textarea class="input" name="profsumm" required placeholder="Your Comment..."></textarea>
					
				</div>

				<div class="wrap-input" style="border-bottom:none;">
					<label class="label">Hobbies:</label>
					
					<input class="inputla" type="text" required name="hob1" placeholder="Ex: cricket" style="font-size: 20px;" pattern="[a-zA-Z \,]*">
					<input class="inputla" type="text" required name="hob2" placeholder="" style="font-size: 20px;" pattern="[a-zA-Z \,]*">
					<input class="inputla" type="text" name="hob3" placeholder="" style="font-size: 20px;" pattern="[a-zA-Z \,]*">
					
				</div>

				<div class="wrap-input" style="border-bottom:none;">
					<label class="label">Programming Skills:</label>
					
					<input class="inputla" type="text" required name="proskill1" placeholder="Ex: Python, Java" style="font-size: 20px;" pattern="[a-zA-Z \,]*">
					<input class="inputla" type="text" required name="proskill2" placeholder="Ex: html, css" style="font-size: 20px;" pattern="[a-zA-Z \,]*">
					<input class="inputla" type="text" name="proskill3" placeholder="Ex: oracle,psql" style="font-size: 20px;" pattern="[a-zA-Z \,]*">
					
				</div>

				<div class="wrap-input" style="margin-bottom: 40px;">
					<label class="label">Other Skills:</label>
					<input class="input" type="text" name="otherskill" placeholder="Enter your other skills ...">
					
				</div>
				<br>
				<div class="wrap-input" style="border-bottom:none;">
					<label class="label">Upload image: </label>
					<input class="input" type="file" required name="photo">
					
				</div>
				<div class="wrap-input" style="border-bottom:none;">
					<label class="label" >Place: </label>
					<input class="input" type="text" required name="place" pattern="[a-zA-Z\,]*" style="border-bottom:2px solid white;">
				</div>
				<div class="wrap-input" style="border-bottom:none;">
					<label class="label">Date: </label>
					<input class="input" type="date" required name="todaydate" style="border-bottom:2px solid white;color: white;">
				</div>

				<div class="formbtn">

					<input class="formbtn" type="submit" name="submit">

				</div>
			</form>
		</div>
		<footer>Copyright © 2022 Create resumes ®</footer>
	</div>

	<script>
		document.getElementById('accls').addEventListener('click', closeNav);
		document.getElementById('rescls').addEventListener('click', closeNav2);

		function openNav() {
		document.getElementById("mySidenav").style.width = "300px";
		}
		function openNav2() {
		document.getElementById("mySidenav2").style.width = "300px";
		}

		function closeNav() {
		document.getElementById("mySidenav").style.width = "0";
		}
		function closeNav2() {
		document.getElementById("mySidenav2").style.width = "0";
		}
	</script>


</body>
</html>


