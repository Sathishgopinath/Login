
Webpages:
	1) index.php --> (Login & Signup)
	2) main.php  --> (Home page)
